﻿app.controller('APIController', function ($scope, APIService) {
    $scope.btnText = "Save";
    debugger
    getAll();
    function getAll() {
        var servCall = APIService.getSubs();
        servCall.then(function (d) {
            $scope.subscriber = d;
        }, function (error) {
            console.log('Oops! Something went wrong while fetching the data.')
        });
    }
    
    $scope.saveSubs = function () {
        var sub = {
            SubscriberID: $scope.subId,
            MailID: $scope.mailid,
            SubscribedDate: new Date()
        };
        if ($scope.btnText == "Save") {
            var saveSubs = APIService.saveSubscriber(sub);
            saveSubs.then(function (d) {
                getAll();
                $scope.Clear();
            }, function (error) {
                console.log('Oops! Something went wrong while saving the data.')
            });
        }
        else {
            var upd = APIService.updateSubscriber(sub);
            upd.then(function (d) {
                getAll();
                $scope.clear();
            }, function (error) {
                console.log('Oops! Something went wrong while updating the data.')
            });
        }
    };

    $scope.dltSubscriber = function (subID) {
        var dlt = APIService.deleteSubscriber(subID);
        dlt.then(function (d) {
            getAll();
        }, function (error) {
            console.log('Oops! Something went wrong while deleting the data.')
        })
    };

    $scope.getSubscriber= function (subID) {
        var get = APIService.getSub(subID);
        get.then(function (response) {
            $scope.subId = response.data.SubscriberID;
            $scope.mailid = response.data.MailID;          
            $scope.subdate = response.data.SubscribedDate;
            $scope.btnText = "Update";
        }, function (error) {
            console.log('Oops! Something went wrong while fetching the data.')
        });
    }

    // Reset details
    $scope.clear = function () {
        $scope.mailid = '';
    }

});