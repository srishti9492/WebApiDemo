﻿var app;
(function () {
    app = angular.module("APIModule", []);    
})();