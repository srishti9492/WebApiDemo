﻿using DAABtest.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Web;

namespace DAABtest.Models
{
    public class EmployeeModel:SQLFactory
    { 
        public EmployeeModel()
        {
                
        }

        public List<Employee> GetAllEmployees()
        {
            List<Employee> listEmployees = new List<Employee>();
            Employee emp;
            IDataReader reader;
            try
            {
                string spName = "sp_GetAllEmployees";
                DbCommand dbCommand = _dbConnection.GetStoredProcCommand(spName);
                using (reader = _dbConnection.ExecuteReader(dbCommand))
                {
                    while (reader.Read())
                    {
                        emp = new Employee();
                        emp.EmployeeID = reader.GetInt32(reader.GetOrdinal("EmployeeID"));
                        emp.FirstName = reader.GetString(reader.GetOrdinal("FirstName"));
                        emp.LastName = reader.GetString(reader.GetOrdinal("LastName"));
                        emp.Age = reader.GetString(reader.GetOrdinal("Age"));
                        emp.Location = reader.GetString(reader.GetOrdinal("Location"));
                        listEmployees.Add(emp);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listEmployees;
        }

        public Employee GetEmployeeById( int empId)
        {
            Employee emp = new Employee();
            IDataReader reader;
            string spName = "sp_GetEmployeeById";
            try
            {
                DbCommand dbCommand = _dbConnection.GetStoredProcCommand(spName);
                _dbConnection.AddInParameter(dbCommand, "EmployeeID", DbType.Int32, empId);
                using (reader = _dbConnection.ExecuteReader(dbCommand))
                {
                    while (reader.Read())
                    {
                        emp.EmployeeID = reader.GetInt32(reader.GetOrdinal("EmployeeID"));
                        emp.FirstName = reader.GetString(reader.GetOrdinal("FirstName"));
                        emp.LastName = reader.GetString(reader.GetOrdinal("LastName"));
                        emp.Age = reader.GetString(reader.GetOrdinal("Age"));
                        emp.Location = reader.GetString(reader.GetOrdinal("Location"));
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return emp;
        }

        public void AddEmployee(Employee emp)
        {
            string spName = "sp_AddNewEmployee";
            try
            {
                DbCommand dbCommand = _dbConnection.GetStoredProcCommand(spName);
                _dbConnection.AddInParameter(dbCommand, "FirstName", DbType.String, emp.FirstName);
                _dbConnection.AddInParameter(dbCommand, "LastName", DbType.String, emp.LastName);
                _dbConnection.AddInParameter(dbCommand, "Age", DbType.String, emp.Age);
                _dbConnection.AddInParameter(dbCommand, "Location", DbType.String, emp.Location);
                _dbConnection.ExecuteNonQuery(dbCommand);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void UpdateEmployee(Employee emp)
        {
            string spName = "sp_UpdateEmployee";
            try
            {
                DbCommand dbCommand = _dbConnection.GetStoredProcCommand(spName);
                _dbConnection.AddInParameter(dbCommand, "EmployeeID", DbType.Int32, emp.EmployeeID);
                _dbConnection.AddInParameter(dbCommand, "FirstName", DbType.String, emp.FirstName);
                _dbConnection.AddInParameter(dbCommand, "LastName", DbType.String, emp.LastName);
                _dbConnection.AddInParameter(dbCommand, "Age", DbType.String, emp.Age);
                _dbConnection.AddInParameter(dbCommand, "Location", DbType.String, emp.Location);
                _dbConnection.ExecuteNonQuery(dbCommand);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void DeleteEmployee(int empId)
        {
            Employee emp = new Employee();
            string spName = "sp_DeleteEmployeeById";
            try
            {
                DbCommand dbCommand = _dbConnection.GetStoredProcCommand(spName);
                _dbConnection.AddInParameter(dbCommand, "EmployeeID", DbType.Int32, empId);
                _dbConnection.ExecuteNonQuery(dbCommand);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}