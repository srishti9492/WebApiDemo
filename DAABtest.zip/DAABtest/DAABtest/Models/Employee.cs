﻿ using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace DAABtest.Models
{
    public class Employee
    {
        public Employee()
        {

        }

        [Key]
        public Int32 EmployeeID { get; set; }

        [Display(Name = "First Name")]
        [Required(ErrorMessage = "First Name is required!")]
        [MinLength(3, ErrorMessage = "Name should be min 3 alphabets long.")]
        [MaxLength(20, ErrorMessage = "Name cannot be more than 20 characters long.")]
        [RegularExpression(@"^([a-zA-Z\s]+)$",ErrorMessage = "Please enter a valid name.")]
        public string FirstName { get; set; }

        [Display(Name = "Last Name")]
        [Required(ErrorMessage = "Last Name is required!")]
        [MaxLength(20, ErrorMessage = "Last Name cannot be more than 20 characters long.")]
        [RegularExpression(@"^([a-zA-Z\s]+)$",ErrorMessage = "Please enter a valid last name.")]
        public string LastName { get; set; }

        
        [Display(Name = "Age")]
        [Required(ErrorMessage = "Age is required!")]
        [RegularExpression(@"^([1-9][1-9]|[2-9][0-9])$", ErrorMessage = "Please enter a valid age.Age should be between 10 to 100.")]
        public string Age { get; set; }

        [Display(Name = "Location")]
        [Required(ErrorMessage = "Location is required!")]
        [MinLength(3, ErrorMessage = "Location should be minimum 3 characters long.")]
        [MaxLength(30, ErrorMessage = "Location cannot be more than 30 characters long.")]
        public string Location { get; set; }
    }
}