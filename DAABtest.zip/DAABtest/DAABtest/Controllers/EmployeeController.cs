﻿using DAABtest.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Objects;
using System.Web.Http;
using System.Web.Http.Cors;

namespace DAABtest.Controllers
{
    [EnableCors(origins: "https://localhost:.....", headers: "*", methods: "*")]
    public class EmployeeController : ApiController
    {
        EmployeeModel model;

        public EmployeeController()
        {

        }

        [HttpGet]
        public List<Employee> CreateEmployeeList()
        {
            try
            {
                model = new EmployeeModel();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return model.GetAllEmployees();
        }

        public Employee Get(int id)
        {
            model = new EmployeeModel();
            Employee emp = new Employee(); ;
            try
            {
                model = new EmployeeModel();
                emp = model.GetEmployeeById(id);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return emp;
        }

        public IHttpActionResult Post(Employee emp)
        {
            model = new EmployeeModel();
            try
            {         
                if (!ModelState.IsValid)
                {                  
                    return BadRequest(ModelState);
                }
                model.AddEmployee(emp);
                return Ok();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public IHttpActionResult Put(Employee emp)
        {
            model = new EmployeeModel();
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                model.UpdateEmployee(emp);
                return Ok();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void Delete(int id)
        {
            model = new EmployeeModel();
            try
            {
                model.DeleteEmployee(id);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
