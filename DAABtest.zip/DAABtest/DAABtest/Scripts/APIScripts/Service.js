﻿app.service("APIService", function ($http) {
    this.getEmps = function () {
        return $http.get("api/Employee");
    }

    this.saveEmployee = function (emp) {
        return $http(
        {
            method: 'post',
            data: emp,
            url: 'api/Employee'
        });
    }

    this.updateEmployee = function (emp) {
        return $http(
        {
            method: 'put',
            data: emp,
            url: 'api/Employee'
        });
    }

    this.deleteEmployee = function (empID) {
        var url = 'api/Employee/' + empID;
        return $http(
        {
            method: 'delete',
            data: empID,
            url: url
        });
    }

    this.getEmp = function (empID) {
        var url = 'api/Employee/' + empID;
        return $http({
            method: 'get',
            data: empID,
            url: url
        });
    }

});
