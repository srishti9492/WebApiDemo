﻿app.controller('APIController', function ($scope, APIService) {
    $scope.btnText = "Save";
    getAll();
    //Get all records 
    function getAll() {
        var servCall = APIService.getEmps();
        servCall.then(function (d) {
            $scope.employee = d.data;
        }, function (error) {
            $log.error('Something went wrong while fetching the data.')
        })
    };
    //Add/update employee
    $scope.saveEmps = function () {
        var emp = {
            EmployeeID: $scope.empId,
            FirstName: $scope.firstName,
            LastName: $scope.lastName,
            Age: $scope.age,
            Location: $scope.location
        };
        if ($scope.btnText == "Save") {
            var emp = {
                EmployeeID:0,
                FirstName: $scope.firstName,
                LastName: $scope.lastName,
                Age: $scope.age,
                Location: $scope.location
            };
            var saveEmps = APIService.saveEmployee(emp);
            saveEmps.then(function (d) {
                getAll();
                $scope.clear();
                $scope.validationErrors = [];
            }, function (error) {
                _showValidationErrors($scope, error);
            });
        }

        else {
            
            var upd = APIService.updateEmployee(emp);
            upd.then(function (d) {
                $scope.btnText = "Save";
                getAll();
                $scope.clear();
                $scope.validationErrors = [];
            }, function (error) {
                _showValidationErrors($scope, error);
            });
        }
    };

    // Show server side validation error 
    function _showValidationErrors($scope, error) {
        $scope.validationErrors = [];
        if (error.data && angular.isObject(error.data)) {
            for (var key in error.data.ModelState) {
                for (var i = 0; i < error.data.ModelState[key].length; i++) {
                    $scope.validationErrors.push(error.data.ModelState[key][i]);
                }
            }
        }
        else {
            $scope.validationErrors.push('Unable to add/update employee records.');
        };
    }

    //Get employee by id
    $scope.getEmployee = function (empID) {
        var get = APIService.getEmp(empID);
        get.then(function (response) {
            $scope.empId = response.data.EmployeeID;
            $scope.firstName = response.data.FirstName;
            $scope.lastName = response.data.LastName
            $scope.age = response.data.Age;
            $scope.location = response.data.Location;
            $scope.btnText = "Update";
        }, function (error) {
            $log.error('Something went wrong while fetching the data.')
        });
    }

    //Delete employee by id
    $scope.dltEmployee = function (empID) {
        var dlt = APIService.deleteEmployee(empID);
        dlt.then(function (d) {
            getAll();
        }, function (error) {
            $log.error('Something went wrong while deleting the data.')
        })
    };

    // Reset form details
    $scope.clear = function () {
        $scope.empId = '';
        $scope.firstName = '';
        $scope.lastName = '';
        $scope.age = '';
        $scope.location = '';
        $scope.validationErrors = [];
        $scope.userForm.$setPristine();
        $scope.userForm.$setUntouched();
        $scope.userForm.$setValidity();
    }

});

app.controller("ListController", ['$scope', '$http',
    function ($scope, $http) {
        $http.get('/api/Employee').success(function (data) {
            $scope.employee = data;
        });
    }
]);



