﻿app.controller('APIController', function ($scope, APIService) {
    getAll();

    function getAll() {
        var servCall = APIService.getEmps();
        servCall.then(function (d) {
            $scope.employee = d.data;
        }, function (error) {
            $log.error('Oops! Something went wrong while fetching the data.')
        })
    };

    $scope.saveSubs = function () {
        var emp = {
            name: $scope.name,
            gender: $scope.gender,
            age: $scope.age,
            salary: $scope.salary
        };
        var saveSubs = APIService.saveEmployees(emp);
        saveSubs.then(function (d) {
            getAll();
        }, function (error) {
            console.log('Oops! Something went wrong while saving the data.')
        })
    };
})


