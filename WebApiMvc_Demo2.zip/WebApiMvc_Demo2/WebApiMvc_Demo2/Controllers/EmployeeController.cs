﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebApiMvc_Demo2.Models;

namespace WebApiMvc_Demo2.Controllers
{
    public class EmployeeController : ApiController
    {
        static readonly IEmployeeRepository employeeRepository = new EmployeeRepository();

        //Get all employees

        //api/employee

        public IEnumerable<Employee> GetAllEmployees()
        {
            return employeeRepository.GetAll();
        }

        public Employee GetEmployee(int id)
        {
            return employeeRepository.Get(id); ;

        }
        public Employee PostEmployee(Employee employee)
        {
            return employeeRepository.Add(employee);
        }

        public Employee PutEmployee(int id, Employee employee)
        {
            employee.id = id;
            return employeeRepository.Update(employee);

        }
        public IEnumerable<Employee> DeleteEmployee(int id)
        {
            return employeeRepository.Delete(id);

        }

    }
}
