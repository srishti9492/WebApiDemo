﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebApiMvc_Demo9.Models;

namespace WebApiMvc_Demo9.Controllers
{
    public class EmployeeController : ApiController
    {
        private EmployeeRecordsEntities myEntity = new EmployeeRecordsEntities();

        public IEnumerable<tbl_Employees> Get()
        {
            return myEntity.tbl_Employees.AsEnumerable();
        }


        public void Post(tbl_Employees sub)
        {
            if (ModelState.IsValid)
            {
                myEntity.tbl_Employees.Add(sub);
                myEntity.SaveChanges();
            }
        }


        public void Put(tbl_Employees sub)
        {
            if (ModelState.IsValid)
            {
                myEntity.Entry(sub).State = EntityState.Modified;
                try
                {
                    myEntity.SaveChanges();
                }
                catch (Exception)
                {
                    throw;
                }
            }
        }

        public void Delete(int id)
        {
            tbl_Employees dlt = myEntity.tbl_Employees.Find(id);
            if (dlt != null)
            {
                try
                {
                    myEntity.tbl_Employees.Remove(dlt);
                    myEntity.SaveChanges();
                }
                catch (Exception)
                {
                    throw;
                }
            }
        }
        public tbl_Employees Get(int id)
        {
            tbl_Employees getSub = myEntity.tbl_Employees.Find(id);
            return getSub;
        }
    }
}

