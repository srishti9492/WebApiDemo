﻿app.controller('APIController', function ($scope, APIService) {
    $scope.btnText = "Save";
    getAll();
    function getAll() {
        var servCall = APIService.getEmps();
        servCall.then(function (d) {
            $scope.employee = d.data;
        }, function (error) {
            $log.error('Oops! Something went wrong while fetching the data.')
        })
    };

    $scope.saveEmps = function () {
        var emp = {
            EmployeeID: $scope.empId,
            FirstName: $scope.firstName,
            LastName: $scope.lastName,
            Age: $scope.age,
            Location: $scope.location
        };
        if ($scope.btnText == "Save") {
            var saveEmps = APIService.saveEmployee(emp);
            saveEmps.then(function (d) {
                getAll();
                $scope.clear();
            }, function (error) {
                console.log('Oops! Something went wrong while saving the data.')
            });
        }
        else {
            var upd = APIService.updateEmployee(emp);
            upd.then(function (d) {
                $scope.btnText = "Save";
                getAll();
                $scope.clear();              
            }, function (error) {
                console.log('Oops! Something went wrong while updating the data.')
            });
        }
    };

    $scope.getEmployee = function (empID) {
        var get = APIService.getEmp(empID);
        get.then(function (response) {
            $scope.empId = response.data.EmployeeID;
            $scope.firstName = response.data.FirstName;
            $scope.lastName = response.data.LastName
            $scope.age = response.data.Age;
            $scope.location = response.data.Location;
            $scope.btnText = "Update";
        }, function (error) {
            console.log('Oops! Something went wrong while fetching the data.')
        });
    }

    $scope.dltEmployee = function (empID) {
        var dlt = APIService.deleteEmployee(empID);
        dlt.then(function (d) {
            getAll();
        }, function (error) {
            console.log('Oops! Something went wrong while deleting the data.')
        })
    };

    // Reset details
    $scope.clear = function () {
        $scope.empId = '';
        $scope.firstName = '';
        $scope.lastName = '';
        $scope.age = '';
        $scope.location = '';

        $scope.userForm.$setPristine();
        $scope.userForm.$setUntouched();
        $scope.userForm.$setValidity();

    }

    $scope.submitForm = function (isValid) {

        // check to make sure the form is completely valid
        if (isValid) {
            alert('our form is amazing');
        }

    };

});


