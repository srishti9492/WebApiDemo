﻿using System.Web.Mvc;

namespace WebApiMvc_Demo9.Areas.ACCOUNT
{
    public class ACCOUNTAreaRegistration : AreaRegistration 
    {
        public override string AreaName 
        {
            get 
            {
                return "ACCOUNT";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context) 
        {
            context.MapRoute(
                "ACCOUNT_default",
                "ACCOUNT/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}